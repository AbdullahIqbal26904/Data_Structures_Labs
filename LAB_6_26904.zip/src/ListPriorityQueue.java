public class ListPriorityQueue<T extends Comparable<T>> implements PriorityQueue<T>{
    Node<T> Front;
    Node<T> Rear;
    public void Enqueue(T obj){
        if(Front == null){
            Front = new Node<>(obj);
            Rear = Front;
            return;
        }
        Node<T> N = new Node<>(obj);
        if(obj.compareTo(Front.data)<0){
            N.next=Front;
            Front=N;
            return;
        }
        if(obj.compareTo(Rear.data)>0){
            Rear.next=N;
            Rear =N;
            return;
        }
        Node<T> temp = Front;
        while (obj.compareTo(temp.next.data)>0 ){
            temp=temp.next;
        }
        Node temp1 = temp.next;
        temp.next=N;
        N.next=temp1;

    }
    public T Dequeue(){
        if(Front == Rear){
            T x = Front.data;
            Front = null;
            return x;
        }else if(Front != null) {
            T x = Front.data;
            Front = Front.next;
            return x;}
        return null;
    }
    public boolean isEmpty(){
            if(Rear == null && Front == Rear){
                return true;
            }
            return false;
    }
    public String toString(){
        Node<T> temp = Front;
        StringBuilder a= new StringBuilder();
        while (temp!=Rear){
           a.append(temp.data).append(",");
           temp=temp.next;
        }
        a.append(temp.data);
        return a.toString();
    }
}
