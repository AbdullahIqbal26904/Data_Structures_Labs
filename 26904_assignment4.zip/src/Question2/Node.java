package Question2;

public class Node {
    String word;
    String meaning;
    Node left;
    Node right;
    public Node(String word,String meaning){
        this.word=word;
        this.meaning=meaning;
    }
}
