package Task1;

import Task1.MyGraph;

public class driver {
    public static void main(String[] args) {
        MyGraph g = new MyGraph(6);
        g.AddVertex("A",13);
        g.AddVertex("B",14);
        g.AddVertex("C",11);
        g.AddVertex("D",21);
        g.AddVertex("E",67);
        g.addEdge("A","C");
        g.addEdge("D","E");
        g.addEdge("B","C");
        g.addEdge("E","A");
//        g.deleteVertex("A");
        System.out.println(g);
        g.DFS();
        System.out.println("path: " );
        g.findPath("A","D");
//        g.deleteEdge("A","E");
//        g.deleteVertex("A");
//        System.out.println(g);
        g.component();
    }
}
