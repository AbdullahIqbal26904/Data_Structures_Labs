public class SortingAlgorithm {
    public void mergeSort(int[] A, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;

            mergeSort(A, left, mid);

            mergeSort(A, mid + 1, right);

            merge(A, left, mid, right);
        }
    }

    public void merge(int[] A, int left, int mid, int right) {
        int size1 = mid - left + 1;
        int size2 = right - mid;
        int[] leftArray = new int[size1];
        int[] rightArray = new int[size2];
        for (int i = 0; i < size1; ++i) {
            leftArray[i] = A[left + i];
        }
        for (int j = 0; j < size2; ++j) {
            rightArray[j] = A[mid + 1 + j];
        }
        int i = 0, j = 0;
        int k = left;
        while (i < size1 && j < size2) {
            if (leftArray[i] <= rightArray[j]) {
                A[k] = leftArray[i];
                i++;
            } else {
                A[k] = rightArray[j];
                j++;
            }
            k++;
        }
        while (i < size1) {
            A[k] = leftArray[i];
            i++;
            k++;
        }
        while (j < size2) {
            A[k] = rightArray[j];
            j++;
            k++;
        }
    }
    public void quickSort(int[] arr, int L, int U) {
        if (L < U) {
            int m = partition(arr, L, U);
            if (m - 1 > L) {
                quickSort(arr, L, m - 1);
            }
            if (m + 1 < U) {
                quickSort(arr, m + 1, U);
            }
        }
    }

    public int partition(int[] arr, int L, int U) {
        int pivot = arr[L];

        int i = L + 1;
        for (int j = L + 1; j <= U; j++) {
            if (arr[j] < pivot) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                i++;
            }
        }
        int temp = arr[L];
        arr[L] = arr[i - 1];
        arr[i - 1] = temp;
        return i - 1;
    }
}
