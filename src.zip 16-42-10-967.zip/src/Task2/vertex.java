package Task2;

public class vertex {
    String label;
    public vertex(String lab){
        this.label=lab;
    }
}
