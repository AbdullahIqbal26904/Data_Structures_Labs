public class DoublyLinkedList<T extends Comparable<T>> {
    Node head;
    public void InsertInorder(T value) { // //Big o is O(N)
       Node<T> curr = head;
       Node<T> N =new Node<>(value);
       if(head==null){
           head =N;
           return;
       }
       while ((curr.next != null) && (value .compareTo(curr.data)>0)){
           curr=curr.next;
       }
       if(curr==head){
           curr.prev=N;
           N.next=curr;
           head=N;
       } else if (curr.next==null && value.compareTo(curr.data)>0) {
           curr.next=N;
           N.prev=curr;
       }else {
           N.prev = curr.prev;
           curr.prev.next=N;
           curr.prev=N;
           N.next=curr;
       }
    }
    //Big o is O(N)
    public Node<T> Find(T value){
        Node<T> temp = head;
        while (temp.next!=null){
            if(temp.data.compareTo(value)==0) return temp;
            temp=temp.next;
        }
        return null;
    }
    //Big o is O(N)
    public String toString(){
        Node<T> curr = head;
        StringBuilder a=new StringBuilder();
        while (curr!=null){
            a.append(curr.data).append(",");
            curr=curr.next;
        }
        return a.toString();
    }
    //Big o is O(N)
    public void deleteNode(T data){
        if(head==null){
            return;
        }
        if(data.compareTo((T) head.data)==0){
            head=head.next;
            head.prev=null;
            return;
        }

        Node<T> a = head;
        while (a.next.data!=data){
            a=a.next;
        }
        a.next=a.next.next;
        a.next.prev=a;
    }
    //Big o is O(1)
    public void clearList(){
        head=null;
    }
    //Big o is O(1)
    public boolean isEmpty(){
        if(head==null){
            return true;
        }
        return false;
    }
    //Big o is O(N)
    public int length(){
        int count=0;
        Node<T> curr = head;
        while (curr!=null){
            count++;
            curr=curr.next;
        }
        return count;
    }
    //Big o is O(N)
    public void reverse() {
        Node<T> temp = null;
        Node<T> curr =head;
        while (curr!=null){
            temp=curr.prev;
            curr.prev=curr.next;
            curr.next=temp;
            curr=curr.prev;
        }
        if(temp!=null){
            head=temp.prev;
        }
    }
}
