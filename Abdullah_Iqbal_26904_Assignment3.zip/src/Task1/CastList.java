package Task1;

public class CastList {
    private Node2 head;
    public void Insert(String name){
        if (head == null){
            head=new Node2(name);
            return;
        }
        Node2 curr = head;
        while (curr.next!=null){
            curr=curr.next;
        }
        Node2 n = new Node2(name);
        curr.next=n;
        n.prev=curr;
    }

    @Override
    public String toString() {
        String a ="";
        Node2 temp = head;
        a+="Actors: ";
        while (temp.next!=null){
            a+= temp.actor+",";
            temp=temp.next;
        }
        a+= temp.actor;
        return a;
    }
}
