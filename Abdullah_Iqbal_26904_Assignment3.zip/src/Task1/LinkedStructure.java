package Task1;

public class LinkedStructure {
    Node head;
    public LinkedStructure(){

    }
    public void insert(String title,int year,CastList l){    //O(N)
        if(head==null){
            head=new Node(title,year,l);
            return;
        }
        Node n = new Node(title,year,l);
        Node temp = head;
        while (temp.next!=null){
            temp=temp.next;
        }
        temp.next=n;
        n.prev=temp;
    }

    public void Delete(String title){    //O(N)
        if(head==null){
            return;
        }
        if(title.equals(head.title)&& head.next==null){
            head=null;
            return;
        }
        if(title.equals(head.title)){
            head=head.next;
            head.prev=null;
            return;
        }
        Node temp = head;
        while (temp.next!=null && !temp.title.equals(title)){
            temp=temp.next;
        }
        if(temp.next==null){
            temp.prev.next=null;
            return;
        }
        temp.prev.next=temp.next;
        temp.next.prev=temp.prev;
    }

    public String Find(String title){    //O(N)
        if(head==null){
            return null;
        }
        Node temp = head;
        while (!temp.title.equals(title)){
            temp=temp.next;
        }
        return temp.year+" "+temp.l;
    }

    @Override
    public String toString() {    //O(N)
        String a ="";
        Node temp = head;
        if(head==null){
            return "No data of this title.";
        }
        while (temp.next!=null){
            a+= "Movie Title: "+temp.title+", Year: "+temp.year+","+temp.l+"\n";
            temp=temp.next;
        }
        a+= "Movie Title: "+temp.title+", Year: "+temp.year+","+temp.l+"\n";
        return a;
    }
}
