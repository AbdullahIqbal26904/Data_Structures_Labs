public class HashTable {
    private int[] Table1;
    private int[] Table2;
    private int[] Table3;
    private int numofCollisions = 0;
    private int numofOccupiedCells = 0;
    private int numofCollisions2 = 0;
    private int numofOccupiedCells2=0;
    private int numofCollisions3 = 0;
    private int numofOccupiedCells3 = 0;

    public int getNumofCollisions() {
        return numofCollisions;
    }

    public int getNumofCollisions2() {
        return numofCollisions2;
    }

    public int getNumofOccupiedCells() {
        return numofOccupiedCells;
    }

    public int getNumofOccupiedCells2() {
        return numofOccupiedCells2;
    }

    public int getNumofCollisions3() {
        return numofCollisions3;
    }

    public int getNumofOccupiedCells3() {
        return numofOccupiedCells3;
    }

    HashTable(int s){
    // table size should be a prime number and 1/3 extra.
        int size=s+(s/3);
        int newSize = getPrime(size);
        Table1=new int [newSize]; // if value is 0 for integer the cell will consider empty.
        Table2=new int [newSize]; // if value is 0 for integer the cell will consider empty.
        Table3=new int [newSize];
    }
    private int getPrime(int n) {
        while(true) {
            if (isPrime(n)) return n;
            n++;
        }
    }
    private boolean isPrime(int n) {
        for (int i = 2; i <= n/2; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
    public int Hash(int key){
        return key%Table1.length;
    }
    public int Hash2(int key){
        return key%Table2.length;
    }
    public int Hash3(int key){
        return key%Table3.length;
    }
    public int Rehash1(int key, int i){
        return ((key%Table1.length)+i)%Table1.length;
    }
    public int Rehash2(int key, int i){
        return ((key%Table2.length)+(i*i))%Table2.length;
    }

    public void insertLinearly(int key){
        int max=0;
        if(((double)numofOccupiedCells)/ Table1.length>0.7) return;
        int mod = Hash(key);
        int i=0;
        int index = mod;
        while (Table1[index]!=0){
            i++;
            index = Rehash1(key,i);
        }
        if(i>numofCollisions){
            numofCollisions = i;
        }
        numofOccupiedCells++;
        Table1[index]=key;
    }
    public void insertQuadratically(int key){
        if(((double)numofOccupiedCells2)/ Table2.length>0.7) return;
        int mod = Hash2(key);
        int i2=0;
        int index2 = mod;
        while (Table2[index2]!=0){
            i2++;
            index2 = Rehash2(key,i2);
        }
        if(i2>numofCollisions2){
            numofCollisions2 = i2;
        }
        numofOccupiedCells2++;
        Table2[index2]=key;
    }
    public boolean search (int key) {
        int a = Hash3(key);
        int i=0;
        int index = a;
        boolean found = false;
        if(key==Table1[a]){
            found = true;
            System.out.println("index got from only hash: "+a);
        }else {
            while (i <= numofCollisions && Table1[index]!=key){
                i++;
                index=Rehash1(key,i);
                if(Table1[index]==key){
                    found = true;
                    System.out.println("index got from rehashing linearly probing: "+index);
                }
            }
        }
        return found;

    }
    public void insertAlternatively(int key){
        if(((double)numofOccupiedCells3)/ Table3.length>0.7) return;
        int mod = Hash3(key);
        int i=0;
        int index = mod;
        while (Table3[index]!=0){
            i++;
            if(i%2==0){
                index = Rehash1(key, i);

            }else {
                index = Rehash2(key,i);
            }
        }
        if(i>numofCollisions3){
            numofCollisions3 = i;
        }
        numofOccupiedCells3++;
        Table3[index]=key;

    }
    public boolean searchFromQuadraticProbing(int key){
        int a = Hash(key);
        int i=0;
        int index=a;
        boolean found = false;
        if(key==Table1[a]){
            System.out.println("index got from only hash: "+a);
            return true;
        }else {
            while (i<=numofCollisions2 && Table2[index] != key){
                i++;
                index = Rehash2(key,i);
                if(Table1[index]==key){
                    found = true;
                    System.out.println("index got from rehashing quadratically probing: "+index);
                }
            }
        }
        return found;
    }
    public boolean searchFromAlternative(int key){
        int a = Hash(key);
        int i=0;
        int index=a;
        boolean found = false;
        if(key==Table3[a]){
            System.out.println("index got from only hash: "+a);
            return true;
        }else {
            while (i<=numofCollisions3 && Table3[index] != key){
                i++;
                if(i%2==0){
                    index = Rehash1(key, i);
                }else {
                    index = Rehash2(key,i);
                }
                if(Table3[index]==key){
                    found = true;
                    System.out.println("index got from rehashing alternative probing: "+index);
                }
            }
        }
        return found;
    }
    public String toString(){
        String str="\nResult from linear probing insertion:- \n";
        for (int i = 0; i < Table1.length; i++) {
            str=str+"["+i+"] "+Table1[i]+",";
        }
        System.out.println("Result from quadratic probing insertion:- ");
        String str2="";
        for (int i = 0; i < Table2.length; i++) {
            System.out.print(str2+"["+i+"] "+Table2[i]+",");
        }
        System.out.println("\nResult from inserting alternatively(first linear then quadratic):- ");
        String str3="";
        for (int i = 0; i < Table3.length; i++) {
            System.out.print(str3+"["+i+"] "+Table3[i]+",");
        }
        return str;
    }
    public boolean search2(int key){
        for (int i=0;i<Table1.length;i++){
            if(Table1[i]==key){
                System.out.println(i);
                return true;
            }
        }
        return false;
    }
}
