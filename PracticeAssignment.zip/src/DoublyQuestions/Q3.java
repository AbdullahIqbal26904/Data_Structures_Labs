package DoublyQuestions;


public class Q3 {
    DoublyLinkedList upper = new DoublyLinkedList();
    DoublyLinkedList lower=new DoublyLinkedList();

    public Node2[] split(DoublyLinkedList l){
        DoublyLinkedList l1=new DoublyLinkedList();
        DoublyLinkedList l2=new DoublyLinkedList();
        Node2[] x = new Node2[2];
        Node2 fast=l.head;
        Node2 slow=l.head;
        while (fast.next!=null){
            l1.insert(slow.data);
            slow=slow.next;
            if(fast.next.next==null){
                while (slow!=null){
                    l2.insert(slow.data);
                    slow=slow.next;
            }
                x[0]=l1.head;
                x[1]=l2.head;
                return x;
        }
            if(fast.next.next.next==null){
                l1.insert(slow.data);
                slow=slow.next;
                while (slow!=null){
                    l2.insert(slow.data);
                    slow=slow.next;
                }
                x[0]=l1.head;
                x[1]=l2.head;
                return x;
            }
            fast=fast.next.next;

        }
        return x;
    }

}
