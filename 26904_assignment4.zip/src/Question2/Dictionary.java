package Question2;

public class Dictionary {
    private Node root;

    public Node getRoot() {
        return root;
    }

    public void insert(String name, String meaning){
        if (root==null){
            root=new Node(name,meaning);
            return;
        }
        Node n = new Node(name,meaning);
        Node curr = root;
        Node prev=null;
        while (curr!=null){
            prev=curr;
            if(name.compareTo(curr.word)<0){
                curr=curr.left;
            }else {
                curr=curr.right;
            }
        }
        if(name.compareTo(prev.word)<0){
            prev.left=n;
        } else {
            prev.right=n;
        }
    }
    public Node find(String word){
        if(root==null){
            return null;
        }
        Node prev=null;
        Node temp = root;
        while (temp!=null){
            prev=temp;
            if(word.compareTo(temp.word)==0) return temp;
            if(word.compareTo(temp.word)<0){
                temp=temp.left;
            }else {
                temp=temp.right;
            }
        }
        return null;
    }
    public static void LNR(Node root)
    {
//        if (root.left==null && root.right == null) return;
        if(root==null) return;
        LNR(root.left);
        System.out.print("Word: "+root.word+" Meaning: "+root.meaning + "\n");
        LNR(root.right);
    }
    private void deleteNoChild(Node root,String name){
        if(name.compareTo(root.word)==0){
            this.root=null;
            System.out.println("root node deleted.");
            return;
        }
        Node prev = null;
        Node temp = root;
        while (temp.word.compareTo(name)!=0){
            prev=temp;
            if(name.compareTo(temp.word)<0){
                temp=temp.left;
            }else {
                temp=temp.right;
            }
        }
        if(name.compareTo(prev.word)<0){
            prev.left=null;
        }else {
            prev.right=null;
        }
    }
    private void deleteOneChild(Node root,String name){
        if(root==null) return;
        if(root.word.compareTo(name)==0){
            if(root.left!=null){
                this.root=root.left;
            }else this.root=root.right;
            return;
        }
        Node temp = root;
        Node prev = null;
        while (name.compareTo(temp.word)!=0){
            prev = temp;
            if(name.compareTo(temp.word)<0){
                temp=temp.left;
            }else {
                temp=temp.right;
            }
        }
        if(prev != null){
            if(name.compareTo(prev.word)<0 && temp.left!=null) {
                prev.left=temp.left;
            }
            else if(name.compareTo(prev.word)>0 && temp.right!=null){
                prev.right=temp.right;
            } else if (name.compareTo(prev.word)<0 && temp.right!=null) {
                prev.left=temp.right;
            }else if (name.compareTo(prev.word)>0 && temp.left!=null) {
                prev.right=temp.left;
            }
        }
    }
    public void delete(String word){
        Node temp = find(word);
        if(temp.left==null && temp.right==null){
            deleteNoChild(root,word);
            return;
        }
        if((temp.right==null && temp.left!=null)||(temp.left==null && temp.right!=null)){
            deleteOneChild(root,word);
            return;
        }
        if(temp.right!=null && temp.left!=null) {
            Node minNode = Minimum(temp.right);
            String s = minNode.word;
            String s2 = minNode.meaning;
            if(minNode.right==null && minNode.left==null){
                deleteNoChild(temp,minNode.word);
                temp.word=s;
                temp.meaning=s2;
            }if((minNode.right==null&&minNode.left!=null) || (minNode.left==null&&minNode.right!=null)){
                deleteOneChild(temp,minNode.word);
                temp.word=s;
                temp.meaning=s2;
            }
        }
    }
    public static Node Minimum(Node root){
        Node temp = root;
        while (temp.left!=null){
            temp=temp.left;
        }
        return temp;
    }
}
