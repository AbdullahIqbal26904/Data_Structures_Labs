import java.util.Scanner;

public class PostFixExpression {
    public static void main(String[] args) {
        System.out.println("Enter equation: ");
        Scanner sc = new Scanner(System.in);
        String a = sc.next();
        System.out.println(postfix(a));
    }
    public static int postfix(String a) {
        int count =0;
        LinkedStack<Integer> stk = new LinkedStack<>();
        while (count<a.length()){
            char symb = a.charAt(count);
            if(symb=='A' ||symb=='B' ||symb=='C' ){
            if (symb=='A'){
                stk.PUSH(3);

            }if (symb=='B'){
                stk.PUSH(2);

            }if (symb=='C'){
                stk.PUSH(1);

            }}
        else{
                int Opnd2 = stk.POP();
                int Opnd1 = stk.POP();
                int val=0;
                if(symb=='+'){
                     val = Opnd1 +Opnd2;

                }
                if(symb=='-'){
                     val = Opnd1 -Opnd2;

                }
                if(symb=='/'){
                     val = Opnd1 /Opnd2;

                }
                if(symb=='*'){
                     val = Opnd1 *Opnd2;

                }
                stk.PUSH(val);
            }
        count++;
        }
       return stk.POP();
    }
}
