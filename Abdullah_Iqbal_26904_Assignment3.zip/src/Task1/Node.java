package Task1;

public class Node  {
    String title;
    int year;
    CastList l;
    Node next;
    Node prev;

    public Node(String title, int year, CastList l) {
        this.title = title;
        this.year = year;
        this.l = l;
    }
}
