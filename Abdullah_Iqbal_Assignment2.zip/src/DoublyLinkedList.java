public class DoublyLinkedList {
    Node head;
    public boolean isEmpty(){
        if(head==null){
            return true;
        }
        return false;
    }
    public int length(){
        if(head==null){
            return 0;
        }
        Node curr = head;
        int count=0;
        while (curr.next!=null){
            count++;
            curr=curr.next;
        }
        return count+1;
    }
    public void print(){
        Node curr = head;
        while (curr.next!=null){
            System.out.print(curr.data+",");
            curr=curr.next;
        }
        System.out.print(curr.data);
        System.out.println();
    }
    public void addAsHead(int data){
        if(head==null){
            head=new Node(data);
            return;
        }
        Node h = new Node(data);
        h.next=head;
        head.prev=h;
        head=h;
    }
    public void addAsTail(int data){
        if(head==null){
            head=new Node(data);
            return;
        }
        Node curr = head;
        while (curr.next!=null){
            curr=curr.next;
        }
        Node h = new Node(data);
        curr.next=h;
        h.prev=curr;
    }
    public void addSorted(int data){
        if(head==null){
            head=new Node(data);
            return;
        }
        Node h = new Node(data);
        if(data<head.data ){
            h.next=head;
            head.prev=h;
            head=h;
            return;
        }
        Node curr = head;
        while (curr.next!=null && data>curr.next.data){
            curr=curr.next;
        }
        if(curr.next == null){
            curr.next=h;
            h.prev=curr;
            return;
        }
        h.next=curr.next;
        h.prev=curr;
        curr.next=h;
        h.next.prev=h;
    }
    public Node find(int i){
        Node curr = head;
        while (curr.next!=null){
            if(curr.data==i){
                return curr;
            }
            curr=curr.next;
        }
        return null;
    }
    public void reverse(){
        Node temp = null;
        Node curr =head;
        while (curr!=null){
            temp=curr.prev;
            curr.prev=curr.next;
            curr.next=temp;
            curr=curr.prev;
        }
        if(temp!=null){
            head=temp.prev;
        }
    }
    public int popHead(){
        if(head!=null){
            int count = head.data;
            head=head.next;
            return count;
        }
        return Integer.parseInt(null);
    }
    public void removeFirst(int i ){
        if(i==head.data){
            head=head.next;
            head.prev=null;
            return;
        }
        Node curr = head;
        while (curr.next!=null){
            if(curr.data==i){
                System.out.println(curr.data+" removed.");
                curr.prev.next=curr.next;
                curr.next.prev=curr.prev;
                return;
            }
            curr=curr.next;
        }
        if( curr.data==i){
            curr.prev.next=null;
        }
    }
    public void removeAll(int i){
        Node curr = head;
        while (curr.next!=null){
            if(i==head.data){
                popHead();
                curr = head;
            }
            if(curr.data==i){
                System.out.println(curr.data+" removed.");
                curr.prev.next=curr.next;
                curr.next.prev=curr.prev;
            }
            curr=curr.next;
        }
        if( curr.data==i){
            curr.prev.next=null;
        }
    }
    public void addAll(DoublyLinkedList l) {
        if (!isEmpty()) {
            Node curr = head;
            while (curr.next != null) {
                curr = curr.next;
            }
            curr.next = l.head;
            l.head.prev=curr;
        }else {
            head = l.head;
        }
    }
}
