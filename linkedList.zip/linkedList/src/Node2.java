public class Node2 <T extends Comparable<T>>{
    T data;
    Node2 next;
    public Node2(T data){
        this.data=data;
    }
}
