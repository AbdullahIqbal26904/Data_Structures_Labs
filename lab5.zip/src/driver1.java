public class driver1 {
    public static void main(String[] args) {
        ArrayStack<Integer> t = new ArrayStack<>(5);
        t.PUSH(12);
        t.PUSH(14);
        t.PUSH(123);
        t.PUSH(1);
//        System.out.println(t.PEEK());
//        System.out.println(t.POP());
//        System.out.println(t.POP());
        LinkedStack<Integer> t1 = new LinkedStack<>();
        t1.PUSH(1432);
        t1.PUSH(123);
        t1.PUSH(543);
        t1.PUSH(987);
        t1.PUSH(5678);
        t1.PUSH(987);
//        System.out.println(t1.POP());
//        System.out.println(t1.POP());
//        System.out.println(t1.POP());
//        System.out.println(t1.POP());
//        System.out.println(t1.POP());
//        System.out.println(t1.POP());
//        System.out.println(t1.POP());
//        System.out.println(t1.PEEK());

    }
}
