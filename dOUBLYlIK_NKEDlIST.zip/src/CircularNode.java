public class CircularNode {
    String name;
    CircularNode next;

    public CircularNode(String name) {
        this.name = name;
        this.next = next;
    }
}
