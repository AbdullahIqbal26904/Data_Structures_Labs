package Task1;

public class Node2 {
    String actor;
    Node2 next;
    Node2 prev;

    public Node2(String actor) {
        this.actor = actor;
    }
}
