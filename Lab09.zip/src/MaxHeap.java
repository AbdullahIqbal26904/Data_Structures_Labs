public class MaxHeap<T extends Comparable<T>> {
    T[] tree;
    int index=0;
    public void Sort(T[] data){
        for (int i = 1; i < data.length; i++) {
            int child = i;
            int parent = (i - 1) / 2;
            while (parent>=0 && data[parent].compareTo(data[child])<0) {
                T temp = data[child];
                data[child] = data[parent];
                data[parent] = temp;
                child=parent;
                parent = (child-1) / 2;
            }
        }
        this.tree=data;
        index=tree.length;
    }
    public void deleteRoot() {
        if (tree.length == 0) {
            return;
        }
        Swap(0,index-1);
        tree[index-1] = null;
        index--;
    }

    private void Swap(int a ,int i) {
        int count=0;
        tree[a] = tree[i];
        tree[i]=null;
        while (2*count+2<i&& 2*count+1<i && (tree[count].compareTo(tree[2*count+1])<0 || tree[count].compareTo(tree[2*count+2])<0)){
            if(tree[count].compareTo(tree[2*count+1])<=0&&tree[count].compareTo(tree[2*count+2])<=0){
                if(tree[2*count+2].compareTo(tree[2*count+1])>0){
                    T temp = tree[2*count+2];
                    tree[2*count+2]=tree[count];
                    tree[count]=temp;
                    count=count*2+2;
                }else {
                    T temp = tree[2*count+1];
                    tree[2*count+1]=tree[count];
                    tree[count]=temp;
                    count=count*2+1;
                }
                continue;
            }
            if(tree[count].compareTo(tree[2*count+1])>=0 && tree[count].compareTo(tree[2*count+2])<0){
                T temp = tree[2*count+2];
                tree[2*count+2]=tree[count];
                tree[count]=temp;
                count=count*2+2;
                continue;
            }
            if(tree[count].compareTo(tree[2*count+1])<=0 && tree[count].compareTo(tree[2*count+2])>0){
                T temp = tree[2*count+1];
                tree[2*count+1]=tree[count];
                tree[count]=temp;
                count=count*2+1;
            }
        }
    }
    public String toString(){
        String s="";
        for (int i=0;i< tree.length;i++){
            s+=tree[i]+" ";
        }
        return s;
    }
}
