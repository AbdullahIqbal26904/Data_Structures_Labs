public class HTListdriver {
    public static void main(String[] args) {
        HTList l = new HTList();
        l.addAsHead(1000);
        l.addAsHead(800);
        l.addAsHead(700);
        l.addAsHead(600);
        l.addAsHead(500);
        l.addAsHead(400);
        l.addAsHead(300);
        l.addAsTail(1100);
        l.addAsTail(1200);
        l.addAsTail(1300);
        l.addAsTail(1400);
        l.addAsTail(1500);
        l.addSorted(350);
        l.addSorted(450);
        l.addSorted(650);
        l.addSorted(1050);
        l.addSorted(1050);
        l.addSorted(1050);
        l.print();
        l.removeAll(1050);
        l.removeFirst(300);
        System.out.println("length of list: "+l.length());
        l.reverse();
        l.print();
        HTList l2 = new HTList();
        l2.addAsHead(2200);
        l2.addAsHead(2100);
        l2.addAsHead(2000);
        l2.addAsTail(2400);
        l2.addSorted(2250);
        l2.print();
        l.reverse();
        l.addAll(l2);
        System.out.println("2 list added to each other :-");
        System.out.println("lenth: "+l.length());
//        Node a = l.find(2250);
//        System.out.println("memory Address of node: "+a);
        l.print();
    }
}
