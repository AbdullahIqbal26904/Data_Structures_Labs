import java.util.Arrays;

public class driver {
    public static void main(String[] args) {
        BST<Integer> n  =new BST<>(50);
        n.insert(44);
        n.insert(40);
        n.insert(50);
        n.insert(35);
        n.insert(42);
        n.insert(41);
        n.insert(45);
        n.insert(60);
        n.insert(55);
        n.insert(80);
        n.insert(30);
        n.insert(20);
        n.insert(34);
//        System.out.println(n.minNode(0));
//        System.out.println(n.find(70));
//        System.out.println(n.find(20));
//        System.out.println(n.find(30));
        System.out.println("before deletion");
        n.traverse(0);
        //        System.out.println(n.find(20));
        n.delete(35);
        n.delete(42);
        n.delete(60);
        n.delete(44);
//        n.delete(60);
//        n.delete(42);
//        n.delete(42);
        System.out.println("\nafter deletion");
//        n.traverse(0);
        n.traverse(0);
//        System.out.println(n.find(20));

    }
}
