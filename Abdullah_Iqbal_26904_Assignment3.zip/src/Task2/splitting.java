package Task2;

import Task1.CastList;
import Task1.LinkedStructure;

import java.util.Objects;

public class splitting {
    LinkedStructure s;
    LinkedStructure s1 ;
    LinkedStructure s2;
    LinkedStructure s3  ;
    LinkedStructure s4 ;
    LinkedStructure s5 ;
    LinkedStructure s6;
    LinkedStructure s7;
    LinkedStructure s8 ;
    LinkedStructure s9 ;
    LinkedStructure s10 ;
    LinkedStructure s11;
    LinkedStructure s12;
    LinkedStructure s13;
    LinkedStructure s14;
    LinkedStructure s15 ;
    LinkedStructure s16;
    LinkedStructure s17;
    LinkedStructure s18;
    LinkedStructure s19;
    LinkedStructure s20;
    LinkedStructure s21;
    LinkedStructure s22 ;
    LinkedStructure s23;
    LinkedStructure s24;
    LinkedStructure s25 ;
    LinkedStructure[] arr = new LinkedStructure[26];

    public splitting(){
        s = new LinkedStructure();
        s1 = new LinkedStructure();
        s2 = new LinkedStructure();
        s3 = new LinkedStructure();
        s4 = new LinkedStructure();
        s5 = new LinkedStructure();
        s6 = new LinkedStructure();
        s7 = new LinkedStructure();
        s8 = new LinkedStructure();
        s9 = new LinkedStructure();
        s10 = new LinkedStructure();
        s11 = new LinkedStructure();
        s12 = new LinkedStructure();
        s13 = new LinkedStructure();
        s14 = new LinkedStructure();
        s15 = new LinkedStructure();
        s16 = new LinkedStructure();
        s17 = new LinkedStructure();
        s18 = new LinkedStructure();
        s19 = new LinkedStructure();
        s20 = new LinkedStructure();
        s21 = new LinkedStructure();
        s22 = new LinkedStructure();
        s23 = new LinkedStructure();
        s24 = new LinkedStructure();
        s25 = new LinkedStructure();
        arr[0]=s;
        arr[1]=s1;
        arr[2]=s2;
        arr[3]=s3;
        arr[4]=s4;
        arr[5]=s5;
        arr[6]=s6;
        arr[7]=s7;
        arr[8]=s8;
        arr[9]=s9;
        arr[10]=s10;
        arr[11]=s11;
        arr[12]=s12;
        arr[13]=s13;
        arr[14]=s14;
        arr[15]=s15;
        arr[16]=s16;
        arr[17]=s17;
        arr[18]=s18;
        arr[19]=s19;
        arr[20]=s20;
        arr[21]=s21;
        arr[22]=s22;
        arr[23]=s23;
        arr[24]=s24;
        arr[25]=s25;
    }
    public void Insert(String title,int year,CastList f){ //O(1)

        int i = title.charAt(0)-65;
        arr[i].insert(title,year,f);
    }

    public void delete(String title){ //O(1)
        int x = title.charAt(0)-65;
        arr[x].Delete(title);
    }
    public String Find(String title){ //O(1)
        int x = title.charAt(0)-65;
        System.out.println("node fount at index location: "+x);
        return "Year and actors of given movie to be found is: "+arr[x].Find(title);
    }
    public String toString(){ //O(N)
        String a="";
        for (int i=0;i<26;i++){
            if(!Objects.equals(arr[i].toString(), "No data of this title.")){
                a+=arr[i]+"\n";
            }
        }
        return a;
    }
}
