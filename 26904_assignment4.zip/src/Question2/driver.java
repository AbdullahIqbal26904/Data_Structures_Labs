package Question2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import static Question2.Dictionary.Minimum;

public class driver {
    public static void main(String[] args) throws IOException {
        String filePath = "src/edited.txt"; // Replace with the path to your dictionary file
        Dictionary d = new Dictionary();
        int count=0;
        int x=0;
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                int lastIndexOfDash = line.indexOf(" ");
                String[] a = line.split( " ");
                if (lastIndexOfDash<0) {
                    x++;
                    continue;
                }
                if ( a.length>1) {
                    if(a[2].equals("n.") || a[2].equals("v.") || a[2].equals("adj.") || a[2].equals("adv.")){
                        String name = a[0] + a[1];
                        String meaning = "";
                        for (int i=2;i<a.length;i++){
                            meaning+=a[i];
                        }
                        d.insert(name, meaning);
                    }else {
                        String name = line.substring(0, lastIndexOfDash).trim();
                        count++;
                        String meaning = line.substring(lastIndexOfDash, line.length());
                            d.insert(name, meaning);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
//        Dictionary.LNR(d.getRoot());
        System.out.println("no. of words: "+count);
        String nameToSearch = "Napalm";
        System.out.println("Meaning of given word to find is: "+d.find(nameToSearch).meaning);
        System.out.println(d.find("Above").meaning);
        d.delete("Above");
        System.out.println(d.find("Above"));
    }
}
