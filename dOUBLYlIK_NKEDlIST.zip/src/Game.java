import java.io.FilterOutputStream;

public class Game {
    CircularNode Tail;
    //Big o is O(1)
    public void insert(String player){
        if(Tail==null){
            Tail = new CircularNode(player);
            Tail.next=Tail;
            return;
        }
        CircularNode n=new CircularNode(player);
        n.next=Tail.next;
        Tail.next=n;
    }
    //Big o is O(n)
    public String toString(){
        CircularNode curr = Tail;
        StringBuilder a=new StringBuilder();
        while (curr.next!=Tail){
            a.append(curr.name).append(",");
            curr=curr.next;
        }
        a.append(curr.name);
        return a.toString();
    }
    //Big o is O(N^R)
    public String playGame(){//
        CircularNode Temp=Tail;
        int count=0;
        while(Tail.next!=Tail){
//            System.out.println("current players are: "+this);
            CircularNode prev = Temp;
            int R = (int) (Math.random()*10);
            while (count<R){
                prev=Temp;
                Temp=Temp.next;
                count++;
            }
            System.out.println("removing: "+Temp.name);
            delete(prev,Temp);

            Temp=Temp.next;
            System.out.println("new turn");
            count=0;
        }
        return Tail.name;  // winner
    }
    //Big o is O(1)
    public void delete(CircularNode prev,CircularNode temp){

        prev.next=temp.next;
        if(temp==Tail){
            Tail=Tail.next;
        }
    }
}
