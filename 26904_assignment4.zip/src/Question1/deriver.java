package Question1;

import Question1.BinaryTree;

public class deriver {
    public static void main(String[] args) {
        BinaryTree<Integer> bst = new BinaryTree<>();

        // Insert some elements
        bst.insert(50);
        bst.insert(30);
        bst.insert(70);
        bst.insert(20);
        bst.insert(40);
        bst.insert(1980);
        bst.insert(2000);
        BinaryTree.PrintRange(bst.root,1,100);
    }
}
