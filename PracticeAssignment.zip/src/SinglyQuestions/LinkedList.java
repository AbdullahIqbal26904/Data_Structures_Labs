package SinglyQuestions;

public class LinkedList {
    Node head;
    public void append(int data) {
        if (head == null) {
            head = new Node(data);
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = new Node(data);
    }
    public void remove(int data) {
        if (head == null) {
            return;
        }
        if (head.data == data) {
            head = head.next;
            System.out.println("data removed");
            return;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.data == data) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }
    public String toString()
    {
        Node curr = head;

        System.out.print("LinkedList: ");
        String a="";
        while (curr != null) {
            a+=curr.data+",";
            curr = curr.next;
        }
        return a;
    }
    public static Node getNode(LinkedList l,int index){ //Q1
        Node current = l.head;
        if (index == 0) {

            return current;
        }
        int count;
        for (count = 0;count < index; count++) {
            current = current.next;
        }
        return current;
    }

    public void InsertNth(LinkedList l,int data, int index){
        int count=0;
        Node n = new Node(data);
        if(index==0){
            n.next=l.head;
            l.head=n;
            return;
        }
        Node temp=l.head;
        while (count<index-1){
            if(temp.next==null) break;
            temp=temp.next;
            count++;
        }
        if(temp.next==null){
            temp.next=n;
            return;
        }
        n.next=temp.next;
        temp.next=n;
    }

}
