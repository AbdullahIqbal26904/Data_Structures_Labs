package Task2;

public class driver {
    public static void main(String[] args) {
        AdjacencyMatrixGraph g = new AdjacencyMatrixGraph(5);
        g.addVertex("abc");
        g.addVertex("efg");
        g.addVertex("hij");
        g.addVertex("lmn");
        g.addVertex("opq");
        g.addEdge("abc","efg");
        g.addEdge("abc","hij");
        g.addEdge("lmn","abc");
        g.addEdge("opq","abc");
        g.display();
    }
}
