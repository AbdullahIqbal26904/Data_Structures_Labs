package DoublyQuestions;

public class Node2 {
    Node2 next;
    Node2 prev;
    int data;

    public Node2(int data) {
        this.data = data;
    }
}
