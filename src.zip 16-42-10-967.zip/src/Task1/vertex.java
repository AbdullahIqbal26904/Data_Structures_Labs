package Task1;
import java.util.LinkedList;

public class vertex {
    String name;
    int age;
    LinkedList<vertex> friendsList;

    public vertex(String name, int age) {
        this.name = name;
        this.age = age;
        friendsList = new LinkedList<>();
    }
    public String getfriendlist(){
        String a ="";
        for (int i=0;i< friendsList.size();i++){
            a+=friendsList.get(i).name+",";
        }
        return a;
    }
}
