public class Question2<T extends Comparable< T>> {
    T[] arr;
    int currIndex;

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    Question2()
    {
        arr = (T[])new Comparable[10];
        currIndex=-1;
    }
    Question2(int size) // constructor to create an array
    {
        arr = (T[])new Comparable[size];
        currIndex=-1;
    }
    public boolean isEmpty(){
        if(currIndex==-1){
            return true;
        }
        return false;
    }
    public int length(){
        return currIndex+1;
    }


    public void print(){
        StringBuilder str= new StringBuilder();
        for(int i=0; i<= currIndex;i++)
            str.append(arr[i]).append("\n");
        System.out.println(str);
    }

    public void addAtFront(T data) // method to add value in an array
    {
        if(currIndex==arr.length-1){
            T[] newArr = (T[])new  Comparable[arr.length*2];
            for (int i=0;i< arr.length;i++){
                newArr[i]=arr[i];
            }
            arr=newArr;
        }
        if(currIndex==-1){
            currIndex++;
            arr[currIndex]=data;
            return;
        }
        for (int i=currIndex;i>=0;i--){
            arr[i+1]=arr[i];
        }
        arr[0]=data;
        currIndex++;
    }
    public void addAtEnd(T data){

        if(currIndex==arr.length-1){
            T[] newArr = (T[])new  Comparable[arr.length*2];
            for (int i=0;i< arr.length;i++){
                newArr[i]=arr[i];
            }
            arr=newArr;
        }
        else if(currIndex<arr.length){
            currIndex++;
            arr[currIndex]=data;
        }
    }
    public int Find(T value){
        for (int i=0 ;i<=currIndex;i++){
            if(arr[i].compareTo(value)==0){
                return i;
            }
        }
        return -1;
    }
    public void reverse(){
        int count= currIndex;
        System.out.println("Values are reversed ");
        for (int i=0;i<=currIndex/2;i++){
            T temp = arr[count];
            arr[count]=arr[i];
            arr[i]=temp;
            count--;
        }
    }
    public void removeFirst(T value){
        for (int i=currIndex;i>=0;i--){
            if(arr[i].compareTo(value)==0){
                for (int j=i;j<= currIndex-1;j++){
                    arr[j]=arr[j+1];
                }
                currIndex--;
                System.out.println("data Removed");
                break;
            }
        }
    }

    public void removeAll(T value){
        for (int i=currIndex;i>=0;i--){
            if(arr[i].compareTo(value)==0){
                for (int j=i;j<= currIndex-1;j++){
                    arr[j]=arr[j+1];
                }
                currIndex--;
                System.out.println("data Removed");
            }
    }
    }
}
