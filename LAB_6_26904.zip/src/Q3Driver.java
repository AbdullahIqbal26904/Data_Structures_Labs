public class Q3Driver {
    public static void main(String[] args) {
//        ArrPriorityQueue<Integer> Q1=new ArrPriorityQueue<Integer>();
//        Q1.Enqueue(21); // 21 kb file size
//        Q1.Enqueue(54);
//        Q1.Enqueue(100);
//        Q1.Enqueue(6);
//        Q1.Enqueue(2);
//        Q1.Enqueue(69);
//        Q1.Enqueue(101);
//        Q1.Enqueue(240);
//
//        System.out.println(Q1.Dequeue());
//        System.out.println(Q1.Dequeue());
//        System.out.println(Q1.Dequeue());
//        System.out.println(Q1.Dequeue());
//        System.out.println(Q1.Dequeue());
//        System.out.println(Q1.Dequeue());
//        System.out.println(Q1.Dequeue());
//        System.out.println(Q1.Dequeue());
//        System.out.println(Q1   );
//        System.out.println(Q1.isEmpty());


//        ListPriorityQueue<Integer> Q2=new ListPriorityQueue<Integer>();
//        System.out.println(Q2.isEmpty());
//        Q2.Enqueue(44);
//        Q2.Enqueue(34);
//        Q2.Enqueue(100);
//        Q2.Enqueue(200);
//        Q2.Enqueue(300);
//        Q2.Enqueue(400);
//        Q2.Enqueue(1);
//        Q2.Enqueue(100);
//        Q2.Enqueue(69);
//        Q2.Enqueue(12);
//        Q2.Enqueue(14);
//        System.out.println(Q2.isEmpty());

//        System.out.println(Q2.Dequeue());
//        System.out.println(Q2.Dequeue());
//        System.out.println(Q2.Dequeue());
//        System.out.println(Q2.Dequeue());
////        System.out.println(Q2.Dequeue());
////        System.out.println(Q2.Dequeue());
////        System.out.println(Q2.Dequeue());
////        System.out.println(Q2.Dequeue());
////        System.out.println(Q2.Dequeue());
////        System.out.println(Q2.Dequeue());
//        System.out.println(Q2);
        ArrPriorityQueue<Integer> Q1=new ArrPriorityQueue<Integer>();
        Q1.Enqueue(21); // 21 kb file size
         Q1.Enqueue(54);
         System.out.println(Q1.Dequeue());
         System.out.println(Q1.Dequeue());
         System.out.println(Q1.Dequeue());
        ListPriorityQueue<Integer> Q2=new ListPriorityQueue<Integer>();
        Q2.Enqueue(44);
        Q2.Enqueue(34);
        System.out.println(Q2.Dequeue()); System.out.println(Q2.Dequeue()); System.out.println(Q2.Dequeue());
    }
}
