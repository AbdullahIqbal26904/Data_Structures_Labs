

public class ArrPriorityQueue  <T extends Comparable<T>> implements PriorityQueue<T>  {
    T[] Q;
    int F;
    ArrPriorityQueue(){
        Q=(T[])new Comparable[10];
        F=-1;
    }
    ArrPriorityQueue(int size){
        Q=(T[])new Comparable[size];
        F=-1;
    }
    public void Enqueue(T Obj){
        if(F==-1){
            F++;
            Q[F]=Obj;
            return;
        }
        if(Obj.compareTo(Q[F])>0){
            int i;
            for ( i=F; i>=0;i--){
                if(Obj.compareTo(Q[i])>0){
                    Q[i+1]=Q[i];
                }else {
                    break;
                }
            }
            Q[i+1] = Obj;
            F++;
        }else {
            F++;
            Q[F]=Obj;
        }
    }
    public String toString() {
        for (int i =0; i <= F; i++){
            System.out.print(Q[i]+",");
        }
        return null;
    }
    public T Dequeue() {
        if(F<0){
            return null;
        }else {
            T x = Q[F];
            F--;
            return x;
        }
    }

    @Override
    public boolean isEmpty() {
        if(F<0){
            return true;
        }else {
            return false;
        }
    }

}
