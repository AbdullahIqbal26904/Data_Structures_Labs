public class ListQueue<T> implements Queues<T> {
    Node<T> Front;
    Node<T> Rear;
    public void enqueue(T obj){
        if(Rear == null){
            Rear = new Node<T>(obj);
            Front=Rear;
            return;
        }
        Node<T> N = new Node<>(obj);
        Rear.next = N;
        Rear = N;
    }
    public  T dequeue(){
        if(Front == Rear){
            T x = Front.data;
            Front = null;
            return x;
        }else if(Front != null) {
        T x = Front.data;
        Front = Front.next;
        return x;}
        return null;
    }
    public boolean isEmpty(){
        if(Rear.next == Front){
            return true;
        }
        return false;
    }

    @Override
    public boolean isFull() {
        return false;
    }
}
