public class StackNode<T> {
    T info;
    StackNode<T> next;

    //Constructor
    StackNode(T data) {
        info = data;
    }
}
