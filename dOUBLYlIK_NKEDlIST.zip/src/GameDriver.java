public class GameDriver {
    public static void main(String[] args) {
        Game g = new Game();
        g.insert("abc");
        g.insert("efg");
        g.insert("hij");
        g.insert("lmn");
        g.insert("opq");
        System.out.println(g);
        System.out.println(g.playGame()+" wins the game");

    }
}
