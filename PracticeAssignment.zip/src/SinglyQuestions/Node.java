package SinglyQuestions;

import DoublyQuestions.Node2;

public class Node {
    Node next;
    int data;

    public Node(int data) {
        this.data = data;
    }
}
