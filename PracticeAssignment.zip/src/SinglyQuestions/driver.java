package SinglyQuestions;

import DoublyQuestions.Q3;

public class driver {
    public static void main(String[] args) {
        LinkedList s = new LinkedList();
        s.append(2);
        s.append(3);
        s.append(5);
        s.append(7);
        s.append(11);
        System.out.println("Q1");
        System.out.println(s);
        System.out.println("Value at given index: "+ LinkedList.getNode(s,4).data);
        System.out.println();
        System.out.println("Q6");
        s.InsertNth(s,100,2);
        s.InsertNth(s,200,0);
        s.InsertNth(s,300,10);
        System.out.println(s);





    }
}
