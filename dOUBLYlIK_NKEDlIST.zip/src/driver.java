public class driver {
    public static void main(String[] args) {
        DoublyLinkedList<Integer> l = new DoublyLinkedList<>();
        l.InsertInorder(12);
        l.InsertInorder(13);
        l.InsertInorder(2);
        l.InsertInorder(156);
        l.InsertInorder(2);
        l.InsertInorder(124);
        l.deleteNode(124);
        System.out.println(l.Find(2));
        //l.deleteNode(12);
        //l.clearList();
        System.out.println(l.isEmpty());
        System.out.println(l.length());

        System.out.println(l);
        l.reverse();
        System.out.println(l);
    }
}
