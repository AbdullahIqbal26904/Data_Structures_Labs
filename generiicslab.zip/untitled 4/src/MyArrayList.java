public class MyArrayList<T extends Comparable<T>>
 {
         T[] arr;
         int currIndex;

         MyArrayList()
         {
         arr = (T[])new Comparable[10];
         currIndex=-1;
         }
         MyArrayList(int size) // constructor to create an array
         {
         arr = (T[])new Comparable[size];
         currIndex=-1;
         }
    public String toString(){
        String str="";
        for(int i=0; i<= currIndex;i++)
        str=str+arr[i]+"\n";
        return str;
        }
    public void add (T data) // method to add value in an array
        {

            if(currIndex==arr.length-1){
                T[] newArr = (T[])new  Comparable[arr.length*2];
                for (int i=0;i< arr.length;i++){
                    newArr[i]=arr[i];
                }
                arr=newArr;
            }
            else if(currIndex<arr.length){
                currIndex++;
                arr[currIndex]=data;
            }
        }
        public int Find(T value){
             for (int i=0 ;i< currIndex;i++){
                 if(arr[i]==value){
                     return i+1;
                 }
             }
             return -1;
        }
        public void clear(){
             for (int i=0;i< arr.length;i++){
                 arr[i]=null;
             }
             currIndex=-1;
        }
     public T get(int value)
     {
         return arr[value];
     }
     public void update(T value,int index)
     {
         arr[index]=value;
     }


     public void remove(T value)
     {
         for (int i=0;i<arr.length;i++){
             if(arr[i]==value){
                 for (int j=i;j< arr.length-1;j++){
                     arr[j]=arr[j+1];
                 }
                 currIndex--;
                 System.out.println("data Removed");
                 break;
             }
         }
     }
 }
