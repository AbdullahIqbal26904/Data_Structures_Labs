import java.util.LinkedList;

public class linkedList {
    Node head;
    public void remove(int data) {
        if (head == null) {

        }
        if (head.data == data) {
            head = head.next;
            System.out.println("data removed");
            return;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.data == data) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    public void InsertInOrder(int data){
        int count=0;
        if(head==null){
            head=new Node(data);
            return;
        }
        if (data< head.data) {
            Node b = new Node(data);
            b.next=head;
            head = b;
        }else {
            Node current = head;
            while (current.next!=null) {
                if(data<current.next.data){
                    break;
                }
                current = current.next;
                count++;
            }
            Node a = current.next;
            current.next = new Node(data);
            current.next.next = a;
        }
    }


    @Override
    public String toString() {
        Node curr = head;
        StringBuilder a= new StringBuilder();
        while (curr!=null){
            a.append(curr.data).append(",");
            curr=curr.next;
        }
        return a.toString();
    }
    public boolean find(int data){
        Node curr = head;
        while (curr.next!=null){
            if(curr.data==data) return true;
            curr=curr.next;
        }
        return false;
    }
    public void clear(){
        head = null;
    }
    public void addAll(linkedList l){
        Node curr=head ;
        while (curr.next!=null){
            curr=curr.next;
        }
        curr.next=l.head;
    }
    public boolean isEmpty(){
        if(head == null) return true;
        else return false;
    }
    public int length(){
        int count=0;
        if(head==null) {
            return 0;
        }
        Node curr = head;
        while (curr.next!=null){
            count++;
            curr=curr.next;
        }
        return count+1;
    }



    public void reverseLinkedList() {
        Node current = head;
        Node prev = null, next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }


}
