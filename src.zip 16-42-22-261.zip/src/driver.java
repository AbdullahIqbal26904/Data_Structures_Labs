public class driver {
    public static void main(String[]args) {
        int[] arr=new int[100];
        int[] arr2=new int[100];

        for(int i=0;i<100;i++){
            arr[i]=(int)(Math.random()*100)+1;
            arr2[i]=(int)(Math.random()*100)+1;
        }
        SortingAlgorithm q = new SortingAlgorithm();
        q.quickSort(arr,0,arr.length-1);
// print arr
        for(int i=0;i<100;i++){
            System.out.print(arr[i]+", ");
        }
        q.mergeSort(arr2,0,arr2.length-1);
        System.out.println();
        for(int i=0;i<100;i++){
            System.out.print(arr2[i]+", ");
        }
    }
}
