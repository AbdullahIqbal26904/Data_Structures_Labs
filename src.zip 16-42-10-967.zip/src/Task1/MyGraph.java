package Task1;

import java.util.*;

public class MyGraph {
     ArrayList<vertex> adjList;
    private int count;
    MyGraph(int s){
        adjList =new ArrayList<>();
        count=0;
    }
    public void AddVertex(String n,int age){
        adjList.add(new vertex(n,age));
    }
    public void addEdge(String n1,String n2){
        vertex v = findVertex(n1);
        vertex v1 = findVertex(n2);
        if(!v.friendsList.contains(v1)){
            v.friendsList.add(v1);
        }
        if( !v1.friendsList.contains(v)){
            v1.friendsList.add(v);
        }
    }
    public void deleteVertex(String n){
        vertex v = findVertex(n);
        for (int i=0;i < adjList.size();i++){
            if(adjList.get(i).friendsList.contains(v)){
                adjList.get(i).friendsList.remove(v);
            }
        }
        adjList.remove(v);
    }

    public void deleteEdge(String n1,String n2){
        vertex v = findVertex(n1);
        vertex v1 = findVertex(n2);
        v.friendsList.remove(v1);
        v1.friendsList.remove(v);
    }

    public String toString(){
        String a="";
        for (int i=0;i< adjList.size();i++){
            a+= "Name: "+adjList.get(i).name+", Age: "+adjList.get(i).age+", Friends: "+adjList.get(i).getfriendlist()+"\n";
        }
        return a;
    }
    public vertex findVertex(String n){
        for (int i=0;i< adjList.size();i++){
            if(adjList.get(i).name.equals(n)){
                return adjList.get(i);
            }
        }
        return null;
    }

    public void DFS() {
        Stack<vertex>s=new Stack<>();
        int[] visit=new int[adjList.size()];
        s.push(adjList.get(0));
        visit[0]=1;
        System.out.println(adjList.get(0).name+" "+adjList.get(0).age);
        while(!s.isEmpty()){
            vertex c1 = s.pop();
            for (vertex neighbor: c1.friendsList){
                int a = getIndex(neighbor.name);
                if(visit[a]!=1){
                    s.push(neighbor);
                    visit[a]=1;
                    System.out.println(neighbor.name+" "+neighbor.age);
                }
            }
        }
    }
    public void findPath(String source,String destination){
        Stack<vertex> s = new Stack<>();
        LinkedList<String> l = new LinkedList<>();
        int[] visited = new int[adjList.size()];
        vertex v1 = findVertex(source);
        vertex v2 = findVertex(destination);
        boolean found = false;
        visited[0]=1;
        s.push(v1);
        l.add(v1.name);
        while (!found){
            vertex c = s.pop();
            for (vertex c1:c.friendsList ){
                int a = getIndex(c1.name);
                if(c1.equals(v2)){
                    found=true;
                }
                if(visited[a]!=1){
                    s.push(c1);
                    visited[a]=1;
                }else if(!s.isEmpty()) {
                    s.pop();
                }
            }
        }
        while (!s.isEmpty()){
            l.add(s.pop().name);
        }
        System.out.println(l);
    }
    public void component(){
        Stack<vertex>s=new Stack<>();
        int[] visit=new int[adjList.size()];
        s.push(adjList.get(0));
        visit[0]=1;
        while(!s.isEmpty()){
            vertex c1 = s.pop();
            for (vertex neighbor: c1.friendsList){
                int a = getIndex(neighbor.name);
                if(visit[a]!=1){
                    s.push(neighbor);
                    visit[a]=1;
                    System.out.println(c1.name+" connected with "+neighbor.name);
                }else if(!s.empty()) {
                    s.pop();
                }
            }
        }
    }
    public int getIndex(String s) {
        for (int i=0;i< adjList.size();i++){
            if(adjList.get(i).name.equals(s)) return i;
        }
        return -1;
    }
    public void BFS(){
        Queue<vertex> q = new LinkedList<>();
        int[] a = new int[adjList.size()];
        q.add(adjList.get(0));
        a[0]=1;
        while (!q.isEmpty()){
            vertex c = q.remove();
            System.out.println(c.name+" "+c.age);
            for (vertex c1 : c.friendsList){
                int index = getIndex(c1.name);
                if(a[index]!=1){
                    q.add(c1);
                    a[index]=1;
                }
            }
        }
    }
    public void shortestPath(String n1,String n2){
        int index1 = getIndex(n1);
        Queue<vertex> q = new LinkedList<>();
        int[] a = new int[adjList.size()];
        a[index1]=1;
        int[] predecessor = new int[adjList.size()];
        for (int i=0;i<predecessor.length;i++){
            predecessor[i]=-1;
        }
        q.add(findVertex(n1));
        while (!q.isEmpty()) {
            vertex c = q.remove();
            for (vertex c1 : c.friendsList) {
                int index = getIndex(c1.name);
                if (a[index] != 1) {
                    predecessor[index] = getIndex(c.name);
                    q.add(c1);
                    a[index] = 1;
                }
            }
        }
            String s ="";
            int ind = getIndex(n2);
            while (predecessor[ind]!=-1){
                s=adjList.get(ind).name + " " + s;
                if(predecessor[ind]==getIndex(n1)){
                    break;
                }else {
                    ind = predecessor[ind];
                }
            }
            System.out.println(n1 + " " + s);
    }
}

