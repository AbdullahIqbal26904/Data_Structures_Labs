package Task1;

import Task1.MyGraph;

public class driver {
    public static void main(String[] args) {
        MyGraph g = new MyGraph(6);
        g.AddVertex("A",13);
        g.AddVertex("B",14);
        g.AddVertex("C",11);
        g.AddVertex("D",21);
        g.AddVertex("E",67);
        g.AddVertex("F",67);
        g.addEdge("A","C");
        g.addEdge("D","E");
        g.addEdge("D","C");
        g.addEdge("B","C");
        g.addEdge("E","A");
        g.addEdge("C","F");
        System.out.println(g);
        g.BFS();
        g.shortestPath("A","F");
    }
}
