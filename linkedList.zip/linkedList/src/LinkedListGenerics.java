public class LinkedListGenerics<T extends Comparable<T>> {
    Node2<T> head;
    public void remove(T data) {
        if (head == null) {

        }
        if (head.data == data) {
            head = head.next;
            System.out.println("data removed");
            return;
        }
        Node2<T> current = head;
        while (current.next != null) {
            if (current.next.data == data) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    public void InsertInOrder(T data){
        int count=0;
        if(head==null){
            head=new Node2<T>( data);
            return;
        }
        if (data.compareTo(head.data)==0) {
            Node2<T> b = new Node2<T>(data);
            b.next=head;
            head = b;
        }else {
            Node2<T> current = head;
            while (current.next!=null) {
                if(data.compareTo(current.data)<0){
                    break;
                }
                current = current.next;
                count++;
            }
            Node2<T> a = current.next;
            current.next = new Node2<T>(data);
            current.next.next = a;
        }
    }


    @Override
    public String toString() {
        Node2<T> curr = head;
        StringBuilder a= new StringBuilder();
        while (curr!=null){
            a.append(curr.data).append(",");
            curr=curr.next;
        }
        return a.toString();
    }
    public boolean find(T data){
        Node2<T> curr = head;
        while (curr.next!=null){
            if(curr.data==data) return true;
            curr=curr.next;
        }
        return false;
    }
    public void clear(){
        head = null;
    }
    public void addAll(LinkedListGenerics<T> l){
        Node2<T> curr=head ;
        while (curr.next!=null){
            curr=curr.next;
        }
        curr.next=l.head;
    }
    public boolean isEmpty(){
        if(head == null) return true;
        else return false;
    }
    public int length(){
        int count=0;
        if(head==null) {
            return 0;
        }
        Node2<T> curr = head;
        while (curr.next!=null){
            count++;
            curr=curr.next;
        }
        return count+1;
    }



    public void reverseLinkedList() {
        Node2<T> current = head;
        Node2<T> prev = null, next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }


}
