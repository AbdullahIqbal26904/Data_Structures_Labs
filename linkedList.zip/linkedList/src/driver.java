public class driver {
    public static void main(String[] args) {
        linkedList l2 = new linkedList();
        l2.InsertInOrder(67);
        l2.InsertInOrder(908);
        linkedList l = new linkedList();
        l.InsertInOrder(10);
        l.InsertInOrder(9);
        l.InsertInOrder(30);
        l.InsertInOrder(10);
        l.InsertInOrder(100);
        l.InsertInOrder(298);
        l.InsertInOrder(50);
        l.InsertInOrder(300);
//        l.addAtSpecIndex(50,1);
//        l.addAtSpecIndex(100,0);
//        l.addAtSpecIndex(150,10);
//        l.insertInOrder(10);
//        l.insertInOrder(20);
//        l.insertInOrder(100);
//        l.insertInOrder(4);
        //l.remove(20);
        //l.remove(298);
        //l.remove(10);
        //l.reverseLinkedList();
        System.out.println(l.length());
        System.out.println(l.find(298));
        System.out.println(l.isEmpty());
        l.addAll(l2);
        System.out.println(l);
    }
}
