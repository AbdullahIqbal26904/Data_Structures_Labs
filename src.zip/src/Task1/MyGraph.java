package Task1;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class MyGraph {
     ArrayList<vertex> adjList;
    private int count;
    MyGraph(int s){
        adjList =new ArrayList<>();
        count=0;
    }
    public void AddVertex(String n,int age){
        adjList.add(new vertex(n,age));
    }
    public void addEdge(String n1,String n2){
        vertex v = findVertex(n1);
        vertex v1 = findVertex(n2);
        if(!v.friendsList.contains(v1)){
            v.friendsList.add(v1);
        }
        if( !v1.friendsList.contains(v)){
            v1.friendsList.add(v);
        }
    }
    public void deleteVertex(String n){
        vertex v = findVertex(n);
        for (int i=0;i < adjList.size();i++){
            if(adjList.get(i).friendsList.contains(v)){
                adjList.get(i).friendsList.remove(v);
            }
        }
        adjList.remove(v);
    }

    public void deleteEdge(String n1,String n2){
        vertex v = findVertex(n1);
        vertex v1 = findVertex(n2);
        v.friendsList.remove(v1);
        v1.friendsList.remove(v);
    }

    public String toString(){
        String a="";
        for (int i=0;i< adjList.size();i++){
            a+= "Name: "+adjList.get(i).name+", Age: "+adjList.get(i).age+", Friends: "+adjList.get(i).getfriendlist()+"\n";
        }
        return a;
    }
    public vertex findVertex(String n){
        for (int i=0;i< adjList.size();i++){
            if(adjList.get(i).name.equals(n)){
                return adjList.get(i);
            }
        }
        return null;
    }

    public void DFS() {
        Stack<vertex>s=new Stack<>();
        int[] visit=new int[adjList.size()];
        s.push(adjList.get(0));
        visit[0]=1;
        System.out.println(adjList.get(0).name+" "+adjList.get(0).age);
        while(!s.isEmpty()){
            vertex c1 = s.pop();
            for (vertex neighbor: c1.friendsList){
                int a = getIndex(neighbor.name);
                if(visit[a]!=1){
                    s.push(neighbor);
                    visit[a]=1;
                    System.out.println(neighbor.name+" "+neighbor.age);
                }else if(!s.empty()) {
                    s.pop();
                }
            }
        }
    }
    public void findPath(String source,String destination){
        Stack<vertex> s = new Stack<>();
        int[] visit=new int[adjList.size()];
        List<String> finalstr = new ArrayList<>();
        vertex v1 = findVertex(source);
        int a1 = getIndex(source);
        finalstr.add(source);
        visit[a1] = 1;
        s.push(v1);
        visit[0]=1;
        System.out.print(adjList.get(0).name+"");
        while (s.peek().name!=destination){
            vertex c1 = s.pop();
            for (vertex neighbor: c1.friendsList){
                int a = getIndex(neighbor.name);
                if(visit[a]!=1){
                    s.push(neighbor);
                    visit[a]=1;
                    System.out.print(" to "+neighbor.name);
                }else if(!s.empty()) {
                    s.pop();
                }
                if(neighbor.name==destination){
                    break;
                }
            }
        }
        System.out.println();
    }
    public void component(){
        Stack<vertex>s=new Stack<>();
        int[] visit=new int[adjList.size()];
        s.push(adjList.get(0));
        visit[0]=1;
        while(!s.isEmpty()){
            vertex c1 = s.pop();
            for (vertex neighbor: c1.friendsList){
                int a = getIndex(neighbor.name);
                if(visit[a]!=1){
                    s.push(neighbor);
                    visit[a]=1;
                    System.out.println(c1.name+" connected with "+neighbor.name);
                }else if(!s.empty()) {
                    s.pop();
                }
            }
        }
    }
    public int getIndex(String s) {
        for (int i=0;i< adjList.size();i++){
            if(adjList.get(i).name.equals(s)) return i;
        }
        return -1;
    }
    }

