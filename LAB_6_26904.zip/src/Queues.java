public interface Queues<T> {
    void enqueue(T obj);
    T dequeue();
    boolean isEmpty();
    boolean isFull();
}
