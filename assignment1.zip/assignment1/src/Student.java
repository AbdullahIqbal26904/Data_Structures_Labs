public class Student implements Comparable<Student> {
    private int age;
    private String name;
    private int id;

    public Student(String name,int age, int id) {
        this.age = age;
        this.name = name;
        this.id = id;
    }

    @Override
    public String toString() {
        return "Student{" +
                "age=" + age +
                ", name='" + name + '\'' +
                ", id=" + id +
                '}';
    }

    @Override
    public int compareTo(Student o) {
        if(o.id == id){
            return 0;
        }else {
            return 1;
        }
    }
}
