package Task1;

public class Node {
    vertex v;
    Node next;

    public Node(vertex v) {
        this.v = v;
    }
}
