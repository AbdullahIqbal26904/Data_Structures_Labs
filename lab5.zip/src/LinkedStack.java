public class LinkedStack <T>{
    StackNode<T> top;

// methods
    public void PUSH(T c){
        StackNode<T> t = new StackNode<>(c);
        t.next=top;
        top=t;
    }
    public T POP() {
        T v = null;
        if(isEmpty()){
            System.out.println("Linked list is empty.");
        }else {
            v=top.info;
            top=top.next;
        }
        return v;
    }
    public T PEEK() {
        if(isEmpty()){
            System.out.println("List is empty");
            return null;
        }
        return top.info;
    }
    public boolean isEmpty() {
        if(top==null){
            return true;
        }
        return false;
    }

}
