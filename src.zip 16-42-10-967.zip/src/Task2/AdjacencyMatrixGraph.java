package Task2;

public class AdjacencyMatrixGraph {
    private vertex[] vertexList;
    private int[][] adjMat;
    private int count;
    public AdjacencyMatrixGraph(int s){
        vertexList = new vertex[s];
        adjMat = new int[s][s];
        count=0;
    }
    public void addVertex(String l){
        vertexList[count]=new vertex(l);
        count++;
    }
    public void addEdge(String l1,String l2){
        int count1=0;
        int count2=0;
        boolean found1 = false;
        boolean found2 = false;
        for (int i=0;i<count;i++){
            if(vertexList[i].label.equals(l1)){
             found1=true;
             count1=i;
             break;
            }
        }
        for (int i=0;i<count;i++){
            if(vertexList[i].label.equals(l2)){
                found2=true;
                count2=i;
                break;
            }
        }
        if(found1&&found2){
            adjMat[count1][count2] = 1;
        }else {
            System.out.println("Vertex not found.");
        }
    }
    public void display(){
        for (int i=0;i< vertexList.length;i++){
            System.out.print(vertexList[i].label +" ");
            for (int x=0;x< vertexList.length;x++){
                System.out.print(adjMat[i][x]+" ");
            }
            System.out.println();
        }
    }
}
