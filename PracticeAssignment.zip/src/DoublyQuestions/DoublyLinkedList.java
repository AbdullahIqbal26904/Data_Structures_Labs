package DoublyQuestions;


public class DoublyLinkedList {
    Node2 head;
    Node2 tail;
    public void insert(int data){
        if(head==null){
            head=new Node2(data);
            tail=head;
            return;
        }
        Node2 N  = new Node2(data);
        N.prev = tail;
        tail.next = N;
        tail = N;
    }
    public String toString()
    {
        Node2 curr = head;

        System.out.print("LinkedList: ");
        String a="";
        while (curr != null) {
            a+=curr.data+",";
            curr = curr.next;
        }
        return a;
    }
    public int length(){
        Node2 curr = head;
        int count=0;
        while (curr.next!=null){
            count++;
            curr=curr.next;
        }
        return count+1;
    }
    public int itemInTheMiddle(){
        Node2 temp = head;
        Node2 temp2 = tail;
        while (temp2.data!=temp.data){
            if(temp.next.data==temp2.data) return temp2.data;
            temp=temp.next;
            temp2=temp2.prev;
        }
        return temp2.data;
    }
    public static DoublyLinkedList sortedMerge(DoublyLinkedList l1, DoublyLinkedList l2){//Q5
        Node2 curr1= l1.head;
        Node2 curr2 = l2.head;
        DoublyLinkedList l3 = new DoublyLinkedList();
        while (curr2!=null && curr1!=null){

            if(curr1.data< curr2.data){
                l3.insert(curr1.data);
                curr1=curr1.next;
            }else {
                l3.insert(curr2.data);
                curr2=curr2.next;
            }
        }
        Node2 temp = curr2;
        Node2 temp2 =curr1;
        while (temp2!=null){
            l3.insert(temp2.data);
            temp2=temp2.next;
        }
        while (temp!=null){
            l3.insert(temp.data);
            temp=temp.next;
        }
        return l3;
    }
    public static void removeDuplicates(DoublyLinkedList l){
        Node2 temp = l.head;
        while (temp.next!=null){
            if(temp.data==temp.next.data){
                temp.next=temp.next.next;
                temp.next.prev=temp;

            }else temp=temp.next;
        }
        System.out.print("Duplicates removed: ");
    }
    public Node2 middleNode(){ //q9
        Node2 fast=head;
        Node2 slow=head;
        while (fast.next!=null){
            slow=slow.next;
            if(fast.next.next==null){
                return slow;
            }
            fast=fast.next.next;
        }
            return slow;
    }
    public static void Append(DoublyLinkedList l1,DoublyLinkedList l2){
        l1.tail.next=l2.head;
        l2.head.prev=l2.tail;
    }
}
