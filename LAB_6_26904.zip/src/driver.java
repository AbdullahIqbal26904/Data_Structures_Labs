public class driver {
    public static void main(String[] args) {
        ArrQueue<String> Q1=new ArrQueue<String>(10);
        Q1.enqueue("JOB1");
        Q1.enqueue("JOB2");
        System.out.println(Q1.dequeue());
        System.out.println(Q1.dequeue());
        System.out.println(Q1.dequeue());
        ListQueue<String> Q2=new ListQueue<String>();
        Q2.enqueue("JOB1");
        Q2.enqueue("JOB2");
        System.out.println(Q2.dequeue());
        System.out.println(Q2.dequeue());
        System.out.println(Q2.dequeue());

    }
}
