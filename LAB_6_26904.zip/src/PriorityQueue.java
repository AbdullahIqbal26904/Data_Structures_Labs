public interface PriorityQueue<T> {
    void Enqueue(T obj);
    T Dequeue();
    boolean isEmpty();
    String toString();
}
