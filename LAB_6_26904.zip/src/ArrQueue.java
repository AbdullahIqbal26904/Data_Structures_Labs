public class ArrQueue<T extends Comparable<T>> implements Queues<T>{
    T[] Q; int F; int R;
    ArrQueue(){
        Q=(T[])new Comparable[10];
        F=0; R=0;
    }
     ArrQueue(int size){
        Q=(T[])new Comparable[size];
        F=0; R=0;
    }

    @Override
    public void enqueue(T obj){
        if((R+1)%Q.length==F){
            System.out.println("list is full.");
        }else {
            R=(R+1)%Q.length;
            Q[R]=obj;
        }
    }
    @Override
    public T dequeue(){
        if(R==F){
            return null;
        }else {
            F=(F+1)%Q.length;
        }
        return Q[F];
    }
    @Override
    public boolean isEmpty(){
        if(F==R){
            return true;
        }
        return false;
    }
    @Override
    public boolean isFull(){
        if((R+1)%Q.length==F){
            return true;
        }
        return false;
    }
}
