import java.util.Random;

public class main {
    public static void main(String args[]){
        HashTable H=new HashTable(100);
        int a=0;
        Random R = new Random();
        for (int i = 0; i < 1000; i++) {
            int i1 = R.nextInt(900) + 100;// generate 3-digit random number
            if(i==5){
                a=i1;
            }
            H.insertLinearly(i1);
            H.insertQuadratically(i1);
            H.insertAlternatively(i1);
        }
        System.out.println(H);
        System.out.println(H.search(a));
        System.out.println(H.searchFromQuadraticProbing(a));
        System.out.println(H.searchFromAlternative(a));
        System.out.println("Number of collisions from linear probing: "+H.getNumofCollisions());
        System.out.println("Number of collisions from quadratic probing: "+H.getNumofCollisions2());
        System.out.println("Number of collisions from alternative probing: "+H.getNumofCollisions3());
        System.out.println("Number of cells occupied linear probing: "+H.getNumofOccupiedCells());
        System.out.println("Number of cells occupied quadratic probing: "+H.getNumofOccupiedCells2());
        System.out.println("Number of cells occupied alternative probing: "+H.getNumofOccupiedCells3());
        System.out.println("linear probing has highest number of rehashing done to insert, than quadratic, than alternative.");
    }
}
