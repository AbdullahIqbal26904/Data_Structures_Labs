package Task2;

import Task1.CastList;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class driver2 {
    public static void main(String[] args) throws IOException {
        CastList l = new CastList();
        l.Insert("Salman Khan");
        l.Insert("Amir Khan");
        l.Insert("Jhon Vick");
        l.Insert("Humayun Saeed");
        CastList l1 = new CastList();
        l1.Insert("Ahad Raza Mir");
        l1.Insert("Fahad Mustafa");
        l1.Insert("Fahad Rehmani");
        l1.Insert("Faisal Qureshi");
        CastList l2 = new CastList();
        l2.Insert("Salman Khan");
        l2.Insert("Amir Khan");
        l2.Insert("Jhon Vick");
        l2.Insert("Humayun Saeed");
        CastList l3 = new CastList();
        l3.Insert("Alizeh Shah");
        l3.Insert("Sajal Ali");
        l3.Insert("Ayeza Khan ");
        l3.Insert("Mahira Khan");
        CastList l4 = new CastList();
        l4.Insert("Adnan Siddiqui");
        l4.Insert("Faisal Qureshi");
        l4.Insert("Atif Aslam");
        l4.Insert("Ali Zafar");
        splitting s = new splitting();
        FileReader file = new FileReader("src/names.txt");
        BufferedReader b = new BufferedReader(file);
        String line;
        List<String> myList = new ArrayList<>();
        while ((line = b.readLine()) != null) {
            myList.add(line);
        }
        CastList f = null;
        Iterator<String> iterator = myList.iterator();
        while (iterator.hasNext()) {
            Random random = new Random();
            int minYear = 2000;
            int maxYear = 2023;
            int randomNumber = random.nextInt(maxYear - minYear + 1) + minYear;
            String element = iterator.next();
            int randomNumber2 = (int) (Math.random()*5+1);
            if(randomNumber2 == 1){
                f =l;
            }
            if(randomNumber2 == 2){
                f =l1;
            }
            if(randomNumber2 == 3){
                f =l2;
            }
            if(randomNumber2 == 4){
                f =l3;
            }
            if(randomNumber2 == 5){
                f =l4;
            }
            s.Insert(element,randomNumber,f);
    }
        b.close();
        file.close();
        System.out.println(s);
        s.delete("Thesis");
        s.delete("Virtual");
        System.out.println(s);
        System.out.println(s.Find("Vocational"));
        System.out.println(s.Find("Sardonic"));
}}
