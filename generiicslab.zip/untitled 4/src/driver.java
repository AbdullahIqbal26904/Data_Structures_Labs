public class driver {
    public static void main(String[] args) {
        MyArrayList<Integer> a = new MyArrayList<>();
        a.add(13);
        a.add(20);
        a.add(21);
        a.add(99);
        a.add(100);
        a.add(123);
        a.add(142);
        a.add(345);
        a.add(67);
        a.add(987);
        a.add(9875);
        a.add(4325);
        a.update(876,6);
        a.remove(99);
        System.out.println("Value at given index at: "+a.get(4));
        System.out.println("value find at index: "+a.Find(20));
        System.out.println(a);
        MyArrayList<String> b = new MyArrayList<>();
        b.add("Abdullah");
        b.add("abc");
        b.add("ghff");
        b.add("hsaiohfafg");
        b.update("klj",1);
        b.clear();
        System.out.println(b);
    }
}
