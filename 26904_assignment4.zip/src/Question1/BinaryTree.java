package Question1;

public class BinaryTree<T extends Comparable<T>> {
    Node<T> root;
    public void insert(T data){
        if (root==null){
            root=new Node<T>(data);
            return;
        }
        Node<T> n = new Node<T>(data);
        Node<T> curr = root;
        Node<T> prev=null;
        while (curr!=null){
            prev=curr;
            if(data.compareTo(curr.data)<0){
                curr=curr.left;
            }else {
                curr=curr.right;
            }
        }
        if(data.compareTo(prev.data)<0){
            prev.left=n;
        } else {
            prev.right=n;
        }
    }
    public static void PrintRange(Node<Integer> r, int k1, int k2){
        if (r == null) return;
        PrintRange(r.left,k1,k2);
        if(r.data.compareTo(k1)>=0 && r.data.compareTo(k2)<=0 ){
            System.out.print(r.data + "\n");
        }
        PrintRange(r.right,k1,k2);
    }
}
