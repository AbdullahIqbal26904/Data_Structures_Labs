public class HTList {
    Node head;
    Node tail;
    public boolean isEmpty(){
        if(head==null){
            return true;
        }
        return false;
    }
    public int length(){
        if(head==null){
            return 0;
        }
        Node curr = head;
        int count=0;
        while (curr.next!=null){
            count++;
            curr=curr.next;
        }
        return count+1;
    }
    public void addSorted(int data){
        Node N  = new Node(data);
        if(head == null){
            head = N;
            tail=head;
            return;
        }
        if(data< head.data){
            N.next = head;
            head.prev = N;
            head = N;
//            System.out.println(head.data);
            return;
        }
        if(data>tail.data){
            N.prev = tail;
            tail.next = N;
            tail = N;
            //System.out.println(tail.data);
            return;
        }
        Node curr = head;
        while (curr.next.next!=null && data>curr.next.data){
            curr=curr.next;
        }
        Node n = new Node(data);
        n.next=curr.next;
        n.prev=curr;
        curr.next=n;
        n.next.prev=n;

    }
    public void addAsHead(int data){
        if(head==null){
            head=new Node(data);
            tail=head;
            return;
        }
        Node N  = new Node(data);
        N.next = head;
        head.prev = N;
        head = N;
    }
    public void addAsTail(int data){
        if(head==null){
            head=new Node(data);
            tail=head;
            return;
        }
        Node N  = new Node(data);
        N.prev = tail;
        tail.next = N;
        tail = N;
    }
    public int popHead(){
        if(head!=null){
            int count = head.data;
            head=head.next;
            head.prev=null;
            return count;
        }
        return Integer.parseInt(null);
    }
    public void removeFirst(int i){
        if(i==head.data){
            popHead();
            return;
        }
        Node curr = head;
        while (curr.next!=null && curr.next.data!=i){
            curr=curr.next;
        }

        if( tail.data==i){
            tail=tail.prev;
            tail.next=null;
            return;
        }
        if(curr!=tail){
        curr.next=curr.next.next;
        curr.next.prev=curr;
        }
    }
    public void removeAll(int i){
        Node curr = head;
        while (curr.next!=null){
            if(i==head.data){
                popHead();
                curr = head;
            }
            if(curr.data==i){
                System.out.println(curr.data+" removed.");
                curr.prev.next=curr.next;
                curr.next.prev=curr.prev;
            }
            curr=curr.next;
        }
        if( tail.data==i){
            tail=tail.prev;
            tail.next=null;
        }
    }
    public void print(){
        Node curr = head;
        while (curr!=null){
            System.out.print(curr.data+",");
            curr=curr.next;
        }
        System.out.println();
    }
    public void reverse(){
        Node temp = null;
        Node curr =head;
        while (curr!=null){
            temp=curr.prev;
            curr.prev=curr.next;
            curr.next=temp;
            curr=curr.prev;
        }
        if(temp!=null){
            head=temp.prev;
        }
    }
    public void addAll(HTList l) {
        if (!isEmpty()) {
            tail.next = l.head;
            l.head=head;
        }else {
            head = l.head;
        }
    }
}
