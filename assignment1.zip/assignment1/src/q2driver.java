public class q2driver {
    public static void main(String[] args) {
        Student s1 = new Student("abc",21,1331);
        Student s2 = new Student("efg",13,1332);
        Student s3 = new Student("hij",23,1333);
        Student s4 = new Student("lmn",12,1334);
        Student s5 = new Student("opq",9,1335);
        Student s6 = new Student("rst",24,1336);
        Student s7 = new Student("uvx",28,1337);
        Student s8 = new Student("wyz",5,1338);
        Student s9 = new Student("wyz",5,1338);
        Student s10 = new Student("wyz",5,1338);
        Question2<Student> s=new Question2<>();
        s.addAtFront(s1);
        s.addAtFront(s2);
        s.addAtEnd(s3);
        s.addAtFront(s4);
        s.addAtFront(s5);
        s.addAtEnd(s6);
        s.addAtEnd(s7);
        s.addAtFront(s8);
        s.addAtFront(s9);
        s.addAtFront(s10);
        s.print();
        System.out.println("Number of students: "+s.length());
        System.out.println("Index of given student is: "+s.Find(s6));
        System.out.println("Index of given student is: "+s.Find(s1));
        s.removeFirst(s8);
        s.reverse();
        System.out.println("Is array empty: "+s.isEmpty());
        s.removeAll(new Student("wyz",5,1338));
        s.print();
//        Question2<Integer> a = new Question2<>();
//        //System.out.println(a.isEmpty());
//        a.addAtFront(10);
//        a.addAtFront(20);
//        a.addAtFront(30);
//        a.addAtFront(100);
//        a.addAtFront(69);
//        a.addAtEnd(90);
//        a.addAtEnd(980);
//        a.addAtFront(10);
//        a.addAtFront(789);
//        a.addAtFront(100);
//        //System.out.println(a.isEmpty());
//        a.print();
//        System.out.println("Number of values: "+a.length());
//        System.out.println("Index of given value is: "+a.Find(100));
//        System.out.println("Index of given value is: "+a.Find(90));
        //a.reverse();
        //a.removeFirst(10);
        //a.removeFirst(10);
        //a.removeFirst(69);
//        a.removeFirst(90);
//        a.removeFirst(789);
        //a.removeFirst(980);
        //a.removeAll(10);
//        a.removeAll(100);
//        a.print();


    }
}
