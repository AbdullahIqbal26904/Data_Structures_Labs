import java.util.Arrays;

public class Question1 {
    public static void main(String[] args) {
        int count = 0;
        int val = -98;
        int[] arr = new int[229];
        int baseAdd = 348;
      for(int i=0;i<229;i++){
          arr[i]=val;
          if(baseAdd==828){
              System.out.println(arr[i]);
              break;
          }
          baseAdd+=4;
          val++;
          count++;
      }
        System.out.println(arr[120]);
        System.out.println(baseAdd);
        System.out.println(arr[70]);
        System.out.println(Arrays.toString(arr));
        System.out.println(count);
        }
    }
