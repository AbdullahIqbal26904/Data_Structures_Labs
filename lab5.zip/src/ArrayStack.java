public class ArrayStack<T extends Comparable<T>> {
    T stackList[];
    int top=-1;
    // constructor
    ArrayStack(int size){
        stackList=(T[]) new Comparable[size];
    }
    // methods
    public void PUSH(T c) {
        if(top== stackList.length-1){
            System.out.println("Array is full!");
            return;
        }
        top++;
        stackList[top]=c;
    }
    public T POP() {
        T val = null;
        if(top<=-1){
            System.out.println("array is empty");
        }else {
            val = stackList[top];
            top--;
            return val;

        }
        return val;
    }
    public T PEEK() {
        if (top == -1){
            return null;
        }else {
            return stackList[top];
        }
    }
    public boolean isEmpty() {
        if(top==-1){
            return true;
        }
        return false;
    }
    public boolean isFull(){
        if(top == stackList.length-1){
            return true;
        }
        return false;
    }
}

