public class driver {
    public static void main(String[] args) {
        Integer[] a = {5,4,9,7,19,8,17,2,6,5,21};
        MaxHeap<Integer> h = new MaxHeap();
        h.Sort(a);
        System.out.println(h);
        h.deleteRoot();
        h.deleteRoot();
        h.deleteRoot();
        System.out.println(h);
        }
    }

