package DoublyQuestions;


import SinglyQuestions.LinkedList;

public class driver {
    public static void main(String[] args) {
        DoublyLinkedList s = new DoublyLinkedList();
        s.insert(2);
        s.insert(3);
        s.insert(5);
        s.insert(7);
        s.insert(8);
        s.insert(9);
        s.insert(10);
        s.insert(11);
        s.insert(11);
        s.insert(11);
        s.insert(11);


        System.out.println(s);
        System.out.println("Q4");
        System.out.println("middle item: "+s.itemInTheMiddle()+"\n");
        Q3 q = new Q3();
        Node2[] a = q.split(s);
        Node2 curr = a[0];
        System.out.println("Q3");

        while (curr!=null){
            System.out.print(curr.data+",");
            curr=curr.next;
        }
        System.out.println();
        Node2 curr2 = a[1];
        while (curr2!=null){
            System.out.print(curr2.data+",");
            curr2=curr2.next;
        }
        System.out.println("\n");

        DoublyLinkedList s2 = new DoublyLinkedList();
        s2.insert(1);
        s2.insert(10);
        s2.insert(20);
        s2.insert(30);
        s2.insert(40);
//        s2.insert(50);
        System.out.println("Q5");
        DoublyLinkedList q5= DoublyLinkedList.sortedMerge(s,s2);
        System.out.println(q5);
        System.out.println("middle item: "+q5.itemInTheMiddle());
//        System.out.println("Value at given index: "+ DoublyLinkedList.getNode(q5,4).data);
        DoublyLinkedList q8 = new DoublyLinkedList();
        q8.insert(10);
        q8.insert(10);
        q8.insert(10);
        q8.insert(13);
        q8.insert(134);
        q8.insert(1678);
        q8.insert(1800);
        q8.insert(1900);
        System.out.println("\nQ8");
        System.out.println(q8);
        DoublyLinkedList.removeDuplicates(q8);
        System.out.println(q8+"\n");
        System.out.println("Q9");
        System.out.println("Middle item from head only "+s.middleNode().data);
        System.out.println(q8);
        DoublyLinkedList s3 = new DoublyLinkedList();
        s3.insert(2);
        s3.insert(22);
        s3.insert(21);
        s3.insert(23);
        s3.insert(2145);
        s3.insert(2123);
        System.out.println("\nQ7");
        DoublyLinkedList.Append(s3,s2);
        System.out.println(s3);

        
    }
}
