public class BST<T extends Comparable<T>>  {
    T[] tree;
    public BST(int size){
        tree = (T[]) new Integer[size];
    }
    public void insert(T d){
        int index=0;
        if(tree[0]==null){
            tree[0] = d;
            return;
        }
        while (index<tree.length && tree[index]!=null){
            if(d .compareTo(tree[index])<0){
                index = index*2+1;
            }else {
                index=index*2+2;
            }
        }
        tree[index]=d;
    }
    public int find(T d){
        int index = 0;
        while (tree[index].compareTo(d)!=0){
        if(d.compareTo(tree[index])<0){
            index=index*2+1;
        }else {
            index=index*2+2;
        }
        }
        return index;
    }
    public void deleteNoChild(T d){
        int x = find(d);
        tree[x]=null;
    }
    public void deleteOneChild(T data){
        int x = find(data);
        if(tree[2*x+1] !=null ){
            preorder(2*x+1);
        }
        else{
            preorder( 2*x+2);
        }
    }
    public void delete(T d){
        int x = find(d);
        if((tree[2*x+1] == null) && (tree[2*x+2] == null)){
            deleteNoChild(d);
        }
        if(((tree[2*x+1] == null) && (tree[2*x+2] != null)||(tree[2*x+1] != null) && (tree[2*x+2] == null))){
         deleteOneChild(d);
        }else if((tree[2*x+1] != null) && (tree[2*x+2] != null)) {
            T c  = minNode(2*x+2);
            int ind = find(c);
            if((tree[2*ind+1] == null) && (tree[2*ind+2] == null)){
                deleteNoChild(c);
                tree[x]=c;
                return;
            }if(((tree[2*x+1] == null) && (tree[2*x+2] != null)||(tree[2*x+1] != null) && (tree[2*x+2] == null))){
                deleteOneChild(c);
                tree[x]=c;
            }
        }

    }
    public T minNode(int index){
        while (tree[2*index+1]!=null){
            index=2*index+1;
        }
        return tree[index];
    }

    public void preorder(int index){
        int a = (int)Math.ceil((double) index /2);
        tree[ a-1] = tree[index];
        tree[index]=null;
        if(tree[2*index+1]!=null){
            preorder( 2*index+1);
        }else if(tree[2*index+2]!=null) {
            preorder(2*index+2);
        }
    }
    public void traverse(int index) {
        if (index < tree.length && tree[index] != null) {
            traverse(index * 2 + 1);
            System.out.print(tree[index] + ",");
            traverse(index * 2 + 2);
        }
    }
}
