import javax.print.DocFlavor;

public class GenericsDriver {
    public static void main(String[] args) {
        LinkedListGenerics<String> s = new LinkedListGenerics<>();
        s.InsertInOrder("abc");
        s.InsertInOrder("bcd");
        s.InsertInOrder("efg");
        s.InsertInOrder("tre");
        s.InsertInOrder("yut");
        s.InsertInOrder("ops");
        System.out.println(s);

    }
}
