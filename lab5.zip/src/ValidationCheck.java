import java.util.Stack;

public class ValidationCheck {
    public static void main(String[] args) {
        System.out.println(validate("[{()}]]"));
    }
    public static boolean validate(String Exp){
        ArrayStack<Character> s = new ArrayStack<>(Exp.length());
        int count=0;
        while (count<Exp.length()){
            char symb=Exp.charAt(count);
            if (symb=='('|| symb=='{' || symb=='[')
                s.PUSH (symb);
                if (symb==')' || symb=='}'|| symb==']') {
                if (s.isEmpty()) return false;
                else{
                    char item=s.PEEK();
                    if ((symb == ']' && item == '['))
                    s.POP();
                    if ((symb == '}' && item == '{'))
                        s.POP();
                    if ((symb == ')' && item == '('))
                        s.POP();

                }
                }
                count++;
        }//end of while
         if(!s.isEmpty() ) return false;
                 else return true;

    }
}
